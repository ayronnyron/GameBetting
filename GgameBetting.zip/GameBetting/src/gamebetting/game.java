/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebetting;

/**
 *
 * @author ayronmonroe
 */
public class game {

    private String name;
    private playerList playerList;
    private double wagerAmount;

    public game() {
        this.name = name;
        this.playerList = playerList;
        this.wagerAmount = wagerAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public playerList getPlayerList() {
        return playerList;
    }

    public void setPlayerList(playerList playerList) {
        this.playerList = playerList;
    }

    public double getWagerAmount() {
        return wagerAmount;
    }

    public void setWagerAmount(double wagerAmount) {
        this.wagerAmount = wagerAmount;
    }

}
