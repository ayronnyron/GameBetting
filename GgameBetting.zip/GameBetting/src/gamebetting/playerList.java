/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebetting;

import java.util.ArrayList;
import javax.swing.JButton;

/**
 *
 * @author ayronmonroe
 */
public class playerList {

    private final ArrayList<player> playerList;
    private final ArrayList<player> fullPlayerList;
    private ArrayList<JButton> opponentList;

    public playerList() {
        playerList = new ArrayList<>();
        fullPlayerList = new ArrayList<>();
        opponentList = new ArrayList<>();
        addPlayersToList();
    }

    public ArrayList<player> getPlayerList() {
        return playerList;
    }

    public ArrayList<player> getFullPlayerList() {
        return fullPlayerList;
    }

    public void addPlayersToList() {
        player player1 = new player("Ayron", "Monroe", 9.7, "Maryland", 3.7);
        fullPlayerList.add(player1);
        player player2 = new player("Murdoch", "Rain", 15.4, "Florida", 4.2);
        fullPlayerList.add(player2);
    }

    public void addPlayer1ToGameList() {
        player player1 = new player("Ayron", "Monroe", 9.7, "Maryland", 3.7);
        playerList.add(player1);
    }

    public void addPlayer2ToGameList() {
        player player2 = new player("Murdoch", "Rain", 15.4, "Florida", 4.2);
        playerList.add(player2);
    }
}
