/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebetting;

/**
 *
 * @author ayronmonroe
 */
public class player {

    private String firstName;
    private String lastName;
    private double balance;
    private String location;
    private double rating;

    public player(String firstName, String lastName, double balance, String location, double rating) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.balance = balance;
        this.location = location;
        this.rating = rating;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    Object getFirstAndLastName() {
        String firstLast = "";
        firstLast += (firstName + " ");
        firstLast += (lastName);
        return firstLast;
    }
}
