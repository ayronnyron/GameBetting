/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Open the app and choose either login or signup. 
//Then input your username/password or create a new one. 
//Once you arrive to the home page you can view your profile page or continue on the the play page where you choose a game. 
//Choose a game, then choose an opponent, enter an amount to wager and choose confirm to confirm this amount. 
//this will simulate the game being played and will show you the outcome in the case that you are the winner. 
//Every page except the initial page and login/register page have a home button that can be clicked to take you back to the home page.
package gamebetting;

/**
 *
 * @author ayronmonroe
 */
public class GameBetting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Controller con = new Controller();
    }

}
