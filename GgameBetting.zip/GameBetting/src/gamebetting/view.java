/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebetting;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

/**
 *
 * @author ayron
 */
public class view extends JFrame {

    private final int indexOfElementToDisplay;

    final view that = this;
    final view loginPage = this;

    private final Controller controller;

    private final JFrame initialFrame;

    private final JPanel initialPanel;
    private final JPanel loginPanel;
    private final JPanel jPanel1;
    private final JPanel playerPanel;
    private final JPanel buttonPanel;
    private final JPanel homePanel;
    private final JPanel registerPanel;
    private final JPanel profilePanel;
    private final JPanel chooseGamePanel;
    private final JPanel opponentPanel;
    private final JPanel wagerPanel;
    private final JPanel resultPanel;

    private final JLabel chooseGame;
    private final JLabel balance;
    private final JLabel record;
    private final JLabel chooseOpponent;
    private final JLabel wagerLabel;
    private final JLabel resultLabel;
    private final JLabel result1;
    private final JLabel result2;

    private final JTextArea usernameField;
    private final JTextArea passwordField;
    private final JTextArea cpasswordField;
    private final JTextArea wagerInput;
    private final JButton homeButton;
    private final JButton profileButton = new JButton("Profile");
    private final JButton playButton = new JButton("Play");
    private final JButton NBA2K19 = new JButton("NBA 2K19");
    private final JButton FortNite = new JButton("FortNite");
    private final JButton SuperSmashBros = new JButton("Super Smash Bros");
    private final JButton addButton = new JButton("Add to balance");
    private final JButton withdrawButton = new JButton("Withdraw from balance");
    private final JButton oppenent1 = new JButton("MurdyNerd, $80, (3.7)");
    private final JButton oppenent2 = new JButton("Jade, $23, (2.1)");
    private final JButton oppenent3 = new JButton("WinnerMAN, $100, (5.0)");
    private final JButton confirmButton = new JButton("Confirm");

    public view(Controller controller, int startingIndexOfDisplay) {
        this.initialFrame = new JFrame();

        this.chooseGame = new JLabel("Choose game");
        this.balance = new JLabel("Current Balance:$5");
        this.record = new JLabel("Wins:27 Losses:0");
        this.chooseOpponent = new JLabel("Choose Opponent");
        this.wagerLabel = new JLabel("Select Wager Amount (Max:$5)");
        this.resultLabel = new JLabel("Winner:");
        this.result1 = new JLabel("Ayronnyron +$5");
        this.result2 = new JLabel("");

        this.usernameField = new JTextArea("Username");
        this.passwordField = new JTextArea("Password");
        this.cpasswordField = new JTextArea("Confirm Password");
        this.wagerInput = new JTextArea("$0.0");

        this.buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        this.playerPanel = new JPanel(new GridLayout(5, 1));
        this.jPanel1 = new JPanel();
        this.initialPanel = new JPanel();
        this.loginPanel = new JPanel();
        this.homePanel = new JPanel();
        this.registerPanel = new JPanel();
        this.profilePanel = new JPanel();
        this.chooseGamePanel = new JPanel();
        this.opponentPanel = new JPanel();
        this.wagerPanel = new JPanel();
        this.resultPanel = new JPanel();

        this.homeButton = new JButton("Home");

        this.controller = controller;
        indexOfElementToDisplay = startingIndexOfDisplay;
        initComponents();
        setFieldView();
    }

    public JPanel loginPanel() {
        return loginPanel;
    }

    public JPanel registerPanel() {
        return registerPanel;
    }

    public JPanel homePanel() {
        return homePanel;
    }

    public JPanel profilePanel() {
        return profilePanel;
    }

    public JPanel chooseGamePanel() {
        return chooseGamePanel;
    }

    public JPanel opponentPanel() {
        return opponentPanel;
    }

    public JPanel wagerPanel() {
        return wagerPanel;
    }

    public JPanel resultPanel() {
        return resultPanel;
    }

    private void initComponents() {
        setSize(196, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Login/Sign-up buttons       
        JButton loginButton = new JButton("Log in");
        loginButton.addActionListener(event -> controller.loginPage());
        initialPanel.add(loginButton, BorderLayout.EAST);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(event -> controller.registerPage());
        initialPanel.add(registerButton, BorderLayout.EAST);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(initialPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Log in/Register");

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(playerPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        homePanel.add(balance);

    }

    private void setFieldView() {
        setTitle("Choose Opponent");
    }

    view loginView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(loginPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Log in");

        loginPanel.add(usernameField, BorderLayout.EAST);
        usernameField.setVisible(true);
        usernameField.setColumns(8);
        usernameField.setRows(1);
        usernameField.setEditable(true);

        loginPanel.add(passwordField, BorderLayout.EAST);
        passwordField.setVisible(true);
        passwordField.setColumns(8);
        passwordField.setRows(1);
        passwordField.setEditable(true);

        JButton loginButton = new JButton("Log in");
        loginButton.addActionListener(event -> controller.login());
        loginPanel.add(loginButton, BorderLayout.EAST);
        return null;
    }

    view registerView() {
        setSize(196, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(registerPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Register");

        registerPanel.add(usernameField, BorderLayout.EAST);
        usernameField.setVisible(true);
        usernameField.setColumns(8);
        usernameField.setRows(1);
        usernameField.setEditable(true);

        registerPanel.add(passwordField, BorderLayout.EAST);
        passwordField.setVisible(true);
        passwordField.setColumns(8);
        passwordField.setRows(1);
        passwordField.setEditable(true);

        registerPanel.add(cpasswordField, BorderLayout.EAST);
        cpasswordField.setVisible(true);
        cpasswordField.setColumns(1);
        cpasswordField.setRows(1);
        cpasswordField.setEditable(true);

        JButton signupButton = new JButton("Register");
        signupButton.addActionListener(event -> controller.register());
        registerPanel.add(signupButton, BorderLayout.EAST);
        return null;
    }

    public JPanel getInitialPanel() {
        return initialPanel;
    }

    view homeView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.setTitle("Welcome to Game Betting!");
        initialFrame.add(homePanel);
        homePanel.add(balance);
        balance.setHorizontalAlignment(JLabel.CENTER);
        balance.setVerticalAlignment(JLabel.TOP);
        homePanel.add(profileButton, BorderLayout.EAST);
        homePanel.add(playButton, BorderLayout.EAST);
        homePanel.setVisible(true);

        profileButton.addActionListener(event -> controller.profile());
        playButton.addActionListener(event -> controller.play());
        return null;
    }

    public view profileView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(profilePanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(190, 230);
        initialFrame.setTitle("Your Profile");

        profilePanel.add(record);
        record.setHorizontalAlignment(JLabel.CENTER);
        record.setVerticalAlignment(JLabel.TOP);

        profilePanel.add(balance);
        balance.setHorizontalAlignment(JLabel.CENTER);
        balance.setVerticalAlignment(JLabel.TOP);

        profilePanel.add(addButton, BorderLayout.EAST);

        profilePanel.add(withdrawButton, BorderLayout.EAST);

        homeButton.addActionListener(event -> controller.home());
        profilePanel.add(homeButton, BorderLayout.EAST);
        return null;
    }

    public view chooseGame() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(chooseGamePanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Ayronnyron $5.0 (4.2)");

        chooseGamePanel.add(chooseGame);
        chooseGame.setHorizontalAlignment(JLabel.CENTER);
        chooseGame.setVerticalAlignment(JLabel.TOP);

        NBA2K19.addActionListener(event -> controller.gameChosen());
        chooseGamePanel.add(NBA2K19, BorderLayout.EAST);

        FortNite.addActionListener(event -> controller.gameChosen());
        chooseGamePanel.add(FortNite, BorderLayout.EAST);

        SuperSmashBros.addActionListener(event -> controller.gameChosen());
        chooseGamePanel.add(SuperSmashBros, BorderLayout.EAST);

        homeButton.addActionListener(event -> controller.home());
        chooseGamePanel.add(homeButton, BorderLayout.EAST);
        return null;
    }

    public view opponentView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(opponentPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Choose Oppenent");

        opponentPanel.add(chooseOpponent);
        chooseOpponent.setHorizontalAlignment(JLabel.CENTER);
        chooseOpponent.setVerticalAlignment(JLabel.TOP);

        oppenent1.addActionListener(event -> controller.opponent());
        opponentPanel.add(oppenent1, BorderLayout.EAST);

        oppenent2.addActionListener(event -> controller.opponent());
        opponentPanel.add(oppenent2, BorderLayout.EAST);

        oppenent3.addActionListener(event -> controller.opponent());
        opponentPanel.add(oppenent3, BorderLayout.EAST);

        homeButton.addActionListener(event -> controller.home());
        opponentPanel.add(homeButton, BorderLayout.EAST);
        return null;
    }

    public view wagerView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(wagerPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Wager");

        wagerPanel.add(wagerLabel);
        wagerLabel.setHorizontalAlignment(JLabel.CENTER);
        wagerLabel.setVerticalAlignment(JLabel.TOP);

        wagerPanel.add(wagerInput, BorderLayout.EAST);
        wagerInput.setVisible(true);
        wagerInput.setColumns(1);
        wagerInput.setRows(1);
        wagerInput.setEditable(true);

        confirmButton.addActionListener(event -> controller.confirm());
        wagerPanel.add(confirmButton, BorderLayout.EAST);

        homeButton.addActionListener(event -> controller.home());
        wagerPanel.add(homeButton, BorderLayout.EAST);
        return null;
    }

    public view resultView() {
        setSize(196, 230);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initialFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        initialFrame.add(resultPanel);
        initialFrame.setVisible(true);
        initialFrame.setSize(196, 230);
        initialFrame.setTitle("Results");

        resultPanel.add(resultLabel);
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setVerticalAlignment(JLabel.TOP);

        resultPanel.add(result1);
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setVerticalAlignment(JLabel.TOP);

        resultPanel.add(result2);
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setVerticalAlignment(JLabel.TOP);

        homeButton.addActionListener(event -> controller.home());
        resultPanel.add(homeButton, BorderLayout.EAST);
        return null;
    }

}
