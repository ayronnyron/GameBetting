/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamebetting;

import javax.swing.JPanel;

/**
 *
 * @author ayronmonroe
 */
public class Controller {

    private static final int STARTING_INDEX_OF_DISPLAY = 0;
    final playerList playerList;
    final playerList fullPlayerList;
    private game game;
    final view view;

    public Controller() {
        playerList = new playerList();
        fullPlayerList = new playerList();
        view = new view(this, STARTING_INDEX_OF_DISPLAY);
        view.setVisible(false);
        game = new game();
    }

    public player getPlayer(int index) {
        return playerList.getPlayerList().get(index);
    }

    public String getGameName(String name) {
        return game.getName();
    }

    public void gameChosen() {
        fullPlayerList.addPlayersToList();
        playerList.addPlayer1ToGameList();
        view.chooseGamePanel().setVisible(false);
        view.opponentPanel().setVisible(true);
        view.opponentView();
    }

    public void loginPage() {
        view.getInitialPanel().setVisible(false);
        view.loginView();
    }

    public void registerPage() {
        view.getInitialPanel().setVisible(false);
        view.registerView();
    }

    public void login() {
        view.loginPanel().setVisible(false);
        view.homeView();
    }

    public void register() {
        view.registerPanel().setVisible(false);
        view.homeView();
    }

    public void profile() {
        view.homePanel().setVisible(false);
        view.profilePanel().setVisible(true);
        view.profileView();
    }

    public void play() {
        view.homePanel().setVisible(false);
        view.chooseGamePanel().setVisible(true);
        view.chooseGame();
    }

    public void home() {
        view.profilePanel().setVisible(false);
        view.chooseGamePanel().setVisible(false);
        view.opponentPanel().setVisible(false);
        view.wagerPanel().setVisible(false);
        view.resultPanel().setVisible(false);
        view.homePanel().setVisible(true);
        view.homeView();
    }

    public void opponent() {
        view.opponentPanel().setVisible(false);
        view.wagerPanel().setVisible(true);
        view.wagerView();
    }

    public void confirm() {
        view.wagerPanel().setVisible(false);
        view.resultPanel().setVisible(true);
        view.resultView();

    }

    public void setHome() {

    }

}
